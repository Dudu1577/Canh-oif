# MedievalCannons 2.1

Plugin experimental para servidores Minecraft Java Paper/Purpur, escrito para Java 25.

## Recursos
- Interface de inventário (`/canhao`) com botões de carregar pólvora, carregar TNT, ajustar elevação, girar mira, disparar e modo de mira.
- Canhão registrado por barril; mire para um barril e use `/canhao criar`.
- Projétil visível, trajetória aproximada com partículas, impacto explosivo configurável.
- Configuração de potência, velocidade, cooldown, munição e dano a blocos.
- Comandos administrativos para criar/remover canhões.

## Importante sobre a versão
A versão de API do Paper `26.2` pode variar por build e disponibilidade no repositório. O `build.gradle.kts` usa uma propriedade `paperApiVersion` configurável (padrão `26.2.build.+`). Se o repositório não resolver esse artefato, defina a versão exata de API publicada para seu servidor no `gradle.properties` ou `build.gradle.kts`.
Este projeto não foi executado em um servidor Minecraft real. O teste de compilação deve ser feito pelo GitHub Actions ou em ambiente com Gradle e a API correspondente.

## Build local
Requer JDK 25 e Gradle 8.14+:
```bash
gradle build
```
JAR: `build/libs/MedievalCannons-2.1.1.jar`

## Instalação
1. Copie o JAR para `plugins/` do Paper/Purpur.
2. Reinicie o servidor.
3. Mire para um barril e use `/canhao criar`.
4. Mire no barril e use `/canhao` para abrir a interface.
5. Clique nos botões da interface para carregar e disparar.

## Comandos
- `/canhao` — abre a interface do canhão registrado mais próximo ou o que você está mirando.
- `/canhao criar` — registra o barril mirado (permissão `medievalcannons.admin`).
- `/canhao remover` — remove o barril mirado.
- `/canhao ajuda` — mostra ajuda.

## Segurança
Explosões podem destruir blocos e causar lag. Teste num mundo de teste e ajuste `explosion-power` e `damage-blocks` em `config.yml`.


## Central de Defesa Mágica

- Receita: esmeraldas nos dois cantos superiores, beacon no centro e blocos de ouro nos dois cantos inferiores.
- Coloque o item fabricado para ativar a central. Ela bloqueia explosões numa esfera de volume elipsoidal configurável (padrão: 50 blocos na horizontal e 50 na vertical).
- A barreira absorve até 8 explosões por padrão. Ao esgotar a carga, a barreira se dissipa, mas o beacon continua colocado.
- Clique com o botão direito no beacon para abrir o painel. O botão de visão liga/desliga as partículas sem desligar a proteção. Também é possível mirar no beacon e usar `/canhao defesa`.
- Os valores ficam em `defense.horizontal-radius-blocks`, `defense.vertical-radius-blocks` e `defense.max-explosions` no `config.yml`.

**Nota:** este projeto foi atualizado no código-fonte, mas ainda precisa ser compilado e testado no servidor Paper/Purpur alvo.


## Central de Defesa Mágica (atualização)

- Receita: esmeraldas nos dois cantos superiores, beacon normal no centro e blocos de ouro nos dois cantos inferiores. O quadrado roxo visto em uma ilustração anterior era apenas um símbolo visual, não um ingrediente; use barras de netherita.
- Proteção em volume elipsoidal: 50 blocos para os lados e 50 blocos verticalmente.
- Até 8 explosões bloqueadas por carga. Ao esgotar, o escudo se dissipa e o beacon permanece.
- Recarga automática gradual: total de 10 minutos para recuperar 8 cargas. Não é necessário inserir itens.
- Clique com o botão direito na central para abrir uma interface própria de 45 slots. O botão de projeção alterna as partículas visuais sem desligar a proteção. O painel informa as cargas e o tempo estimado para a próxima.
- Também é possível mirar na central e usar `/canhao defesa`.

Observação: o código-fonte foi atualizado, mas precisa ser compilado e testado no ambiente Paper/Purpur alvo antes de ser instalado no servidor.


## MedievalCannons 2.1 — integração e receitas

- Canhão: ao colocar o barril fabricado, o plugin registra o canhão automaticamente.
- Receita do canhão (linha a linha): `IDI` / `PBF` / `DRP`; I=bloco de ferro (2), D=diamante (2), P=pólvora (2), B=barril, F=pederneira e aço, R=redstone.
- O canhão consome apenas TNT de Impulso marcada pelo plugin TNTReinforced 1.3.0 (`tntreinforced:tnt_impulse_item`), não TNT comum nem pólvora. Mantenha TNTReinforced instalado para obter e identificar essa munição.
- Alcance máximo do projétil: 65 blocos; recarga do canhão: 5 segundos; potência, recarga e dano ao terreno permanecem configuráveis.
- Barreira mágica normal: `E E` / ` B ` / `G G`; E=esmeralda, B=beacon, G=bloco de ouro; até 8 cargas.
- Barreira mágica reforçada: `ONO` / `NBN` / `ONO`; O=obsidiana chorona, N=lingote de netherita, B=beacon. Receita avançada: 4 lingotes de netherita, 4 obsidianas choronas e 1 beacon. Proteção: 80 blocos na horizontal, 100 na vertical, 16 cargas e recarga completa em 45 minutos.

## Créditos
- MedievalCannons base e integração: ElementalCraft BR.
- Compatibilidade da TNT de Impulso: integração baseada nos identificadores públicos do item do TNTReinforced 1.3.0, de zSouul. TNTReinforced permanece um plugin separado e deve estar instalado para criar/obter a munição especial.

## Compilação
Requer JDK 25 e Gradle 8.14+ conforme `build.gradle.kts`. Execute `gradle build`; o JAR será criado em `build/libs/MedievalCannons-2.1.1.jar`. Teste primeiro em servidor de teste.


## Ajustes solicitados para a versão 2.1
- Canhão: alcance máximo 65 blocos e cooldown de 5 segundos.
- Defesa normal: raio horizontal/vertical de 50 blocos, 8 cargas e recarga total de 10 minutos.
- Barreira reforçada: receita difícil com 4 lingotes de netherita, 4 obsidianas choronas e 1 beacon; alcance horizontal 80, vertical 100, até 16 cargas e recarga total de 45 minutos.
- O workflow publica o JAR como artefato do GitHub Actions. Ainda é obrigatório confirmar build verde e testar em servidor.


## Receitas visíveis no jogo (comando `/canhao receitas`)

Os ingredientes abaixo são itens reais do Minecraft; não foram inventados itens de receita.

### Canhão Medieval

```text
I D I
P B F
D R P
```

- `I`: bloco de ferro (2); `D`: diamante (2); `P`: pólvora (2); `B`: barril; `F`: pederneira e aço; `R`: redstone.
- Alcance máximo: 65 blocos. Recarga: 5 segundos.
- Munição: somente TNT de Impulso reconhecida pela integração do TNTReinforced 1.3.0; o TNTReinforced precisa estar instalado.

### Barreira Mágica Azul (normal)

```text
E . E
. B .
G . G
```

- `E`: esmeralda; `B`: beacon; `G`: bloco de ouro; `.`: espaço vazio.
- Proteção: 50 blocos horizontalmente e 50 verticalmente; 8 explosões; recarga completa em 10 minutos.
- Projeção visual azul com partículas de chama azul (SOUL_FIRE_FLAME).

### Barreira Mágica Roxa (reforçada)

```text
O N O
N B N
O N O
```

- `O`: obsidiana chorona; `N`: lingote de netherita; `B`: beacon.
- Proteção: 80 blocos horizontalmente e 100 verticalmente; 16 explosões; recarga completa em 45 minutos.
- Projeção visual roxa com partículas de bafo de dragão (DRAGON_BREATH).

Use `/canhao receitas` para ver as receitas e especificações no chat do jogo. Para alternar a projeção de uma barreira, clique com o botão direito no beacon e use o botão de projeção no painel; ocultar a projeção não desativa a proteção.

## Verificação de compilação

O workflow usa Java 25 e Paper API `26.2.build.129-stable`. Ele deve falhar se o JAR não contiver `plugin.yml`, `config.yml` e a classe principal, ou se o arquivo tiver menos de 10 KB. Isso impede que um JAR de poucos bytes seja publicado como artefato válido. Ainda é necessário executar o workflow e testar o plugin num servidor de teste Paper/Purpur 26.2 antes de usá-lo em produção.

**Escopo conhecido desta versão:** inclui um tipo de canhão e duas barreiras mágicas. Não inclui três modelos diferentes de canhão porque as especificações completas dos outros modelos não estão no código-fonte recebido; não foram inventadas receitas ou atributos para eles.


## Receitas oficiais e créditos
Consulte `src/main/resources/recipes.yml` para as receitas, a quantidade exata de itens vanilla e os créditos.
O comando `/canhao receitas` mostra a grade do canhão e as grades das duas barreiras.

## Integração TNTReinforced 1.3.0
O JAR TNTReinforced fornecido foi inspecionado: seu item usa o PDC `tntreinforced:tnt_impulse_item`, e a entidade de TNT de Impulso usa `tntreinforced:tnt_impulse_entity`. O MedievalCannons verifica o primeiro ao carregar munição e marca a TNTPrimed de impacto com o segundo para que o listener do TNTReinforced reconheça a explosão. `TNTReinforced` é uma dependência opcional (`softdepend`); sem ele, os canhões não disparam, evitando explosões incompatíveis.

## Limites de verificação
O pacote foi corrigido por inspeção estática, mas não foi possível executar uma compilação real nem testar em servidor Paper/Purpur 26.2 neste ambiente. Não é honesto garantir ausência de 100% dos erros sem build e teste em servidor. O workflow do GitHub Actions usa Java 25 e deve ser executado antes de instalar o artefato.


## Revisão de integração (versão de código 2.1.1)
- Receita do canhão ajustada exatamente aos ingredientes pedidos: 2 blocos de ferro, 1 redstone, 2 pólvoras, 2 diamantes, 1 pederneira e aço e 1 barril.
- Adicionado `recipes.yml` com as receitas, quantidades, especificações e créditos, copiado para a pasta de dados do plugin.
- `plugin.yml` declara `TNTReinforced` como `softdepend`.
- A integração foi comparada ao JAR TNTReinforced 1.3.0 enviado: chave de item `tntreinforced:tnt_impulse_item`; chave de entidade `tntreinforced:tnt_impulse_entity`.
- O projétil do canhão agora gera uma TNTPrimed marcada com a chave de entidade esperada pelo TNTReinforced, para que o evento passe pelo sistema de TNT de Impulso.
- O limite de alcance/tempo é verificado mesmo quando a opção de partículas de trajetória está desligada.
- O workflow exige classes, descritores e recipes.yml no JAR e falha se o artefato for minúsculo.

**Atenção:** esta é uma correção por inspeção estática, não uma garantia de 100%. É obrigatório executar o workflow de Java 25 e fazer um teste em servidor Paper/Purpur 26.2 antes de produção. O ambiente desta conversa não possui JDK 25 nem Gradle instalados, então o JAR final não foi compilado aqui.
