package br.elementalcraft.cannons;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public final class MedievalCannons extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<String, CannonState> cannons = new HashMap<>();
    private final Map<UUID, String> openMenus = new HashMap<>();
    private final Map<String, Long> cooldowns = new HashMap<>();
    private NamespacedKey projectileKey;
    private NamespacedKey ownerKey;
    private NamespacedKey specialBeaconKey;
    private NamespacedKey reinforcedBeaconKey;
    private NamespacedKey cannonItemKey;
    // PDC identifiers used by TNTReinforced 1.3.0 (shared namespace across plugins).
    private NamespacedKey impulseItemKey;
    private NamespacedKey impulseEntityKey;
    private NamespacedKey projectileLastLocationKey;
    private final Map<String, DefenseState> defenses = new HashMap<>();
    private final Map<UUID, String> openDefenseMenus = new HashMap<>();
    private static final String DEFENSE_TITLE = ChatColor.DARK_PURPLE + "Central de Defesa Mágica";
    private static final int DEFENSE_MENU_SIZE = 27;

    private static final int MENU_SIZE = 27;
    private static final String MENU_TITLE = ChatColor.DARK_GRAY + "MedievalCannons 2.1";

    private static final class DefenseState {
        final String key;
        final Location location;
        final boolean reinforced;
        int hitsRemaining;
        boolean active = true;
        boolean visible = false;
        long lastRechargeMillis;
        DefenseState(String key, Location location, int hitsRemaining, boolean active, boolean visible, long lastRechargeMillis) {
            this(key, location, hitsRemaining, active, visible, lastRechargeMillis, false);
        }
        DefenseState(String key, Location location, int hitsRemaining, boolean active, boolean visible, long lastRechargeMillis, boolean reinforced) {
            this.key = key; this.location = location; this.reinforced = reinforced; this.hitsRemaining = hitsRemaining; this.active = active; this.visible = visible;
            this.lastRechargeMillis = lastRechargeMillis > 0 ? lastRechargeMillis : System.currentTimeMillis();
        }
    }

    private static final class CannonState {
        final String key;
        final Location location;
        UUID owner;
        int tnt = 0;
        double yaw;
        double elevation;
        CannonState(String key, Location location, UUID owner, double yaw, double elevation) {
            this.key = key; this.location = location; this.owner = owner;
            this.yaw = yaw; this.elevation = elevation;
        }
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        saveResource("recipes.yml", false);
        projectileKey = new NamespacedKey(this, "cannon_projectile");
        ownerKey = new NamespacedKey(this, "cannon_owner");
        specialBeaconKey = new NamespacedKey(this, "magic_defense_beacon");
        reinforcedBeaconKey = new NamespacedKey(this, "reinforced_magic_defense_beacon");
        cannonItemKey = new NamespacedKey(this, "cannon_item");
        impulseItemKey = new NamespacedKey("tntreinforced", "tnt_impulse_item");
        impulseEntityKey = new NamespacedKey("tntreinforced", "tnt_impulse_entity");
        projectileLastLocationKey = new NamespacedKey(this, "projectile_last_location");
        loadCannons();
        loadDefenses();
        registerDefenseRecipe();
        registerReinforcedDefenseRecipe();
        registerCannonRecipe();
        Bukkit.getScheduler().runTaskTimer(this, this::renderDefenseBarriers, 10L, 10L);
        Objects.requireNonNull(getCommand("canhao")).setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        if (!isTntReinforcedAvailable()) {
            getLogger().warning("TNTReinforced não está ativo. As barreiras e receitas continuam disponíveis, mas o disparo de TNT de Impulso ficará bloqueado até ativar TNTReinforced.");
        }
        getLogger().info("MedievalCannons 2.1 ativado. Receitas documentadas em recipes.yml. Créditos da integração: TNTReinforced 1.3.0 por zSouul.");
    }

    @Override public void onDisable() { saveCannons(); saveDefenses(); }

    private String key(Location l) {
        return l.getWorld().getName() + ":" + l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }

    private Location fromKey(String s) {
        String[] p = s.split(":");
        if (p.length != 4) return null;
        World w = Bukkit.getWorld(p[0]);
        if (w == null) return null;
        try { return new Location(w, Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])); }
        catch (NumberFormatException e) { return null; }
    }

    private void loadCannons() {
        for (String s : getConfig().getStringList("registered-cannons")) {
            Location l = fromKey(s);
            if (l != null) cannons.put(key(l), new CannonState(key(l), l, new UUID(0L,0L), 0, 15));
        }
    }

    private void saveCannons() {
        getConfig().set("registered-cannons", new ArrayList<>(cannons.keySet()));
        saveConfig();
    }

    private void loadDefenses() {
        for (String entry : getConfig().getStringList("defense-beacons")) {
            String[] parts = entry.split("\\|");
            if (parts.length < 4) continue;
            Location loc = fromKey(parts[0]);
            if (loc == null) continue;
            try {
                boolean reinforced = parts.length >= 6 && Boolean.parseBoolean(parts[5]);
                int maxHits = reinforced ? Math.max(1, Math.min(16, getConfig().getInt("reinforced-defense.max-explosions", 16))) : Math.max(1, Math.min(8, getConfig().getInt("defense.max-explosions", 8)));
                int hits = Math.max(0, Math.min(maxHits, Integer.parseInt(parts[1])));
                long lastRecharge = parts.length >= 5 ? Long.parseLong(parts[4]) : System.currentTimeMillis();
                defenses.put(key(loc), new DefenseState(key(loc), loc, hits, Boolean.parseBoolean(parts[2]), Boolean.parseBoolean(parts[3]), lastRecharge, reinforced));
            } catch (NumberFormatException ignored) { }
        }
    }

    private void saveDefenses() {
        List<String> entries = new ArrayList<>();
        for (DefenseState d : defenses.values()) entries.add(d.key + "|" + d.hitsRemaining + "|" + d.active + "|" + d.visible + "|" + d.lastRechargeMillis + "|" + d.reinforced);
        getConfig().set("defense-beacons", entries);
        saveConfig();
    }

    private ItemStack specialBeaconItem() {
        ItemStack stack = item(Material.BEACON, "Central de Defesa Mágica", "Protege explosões em 50 blocos para os lados", "50 blocos para cima e para baixo", "Suporta até 8 explosões", "Recarga gradual completa em 10 minutos", "Clique direito no bloco para abrir o painel");
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "Barreira Mágica Azul");
        meta.getPersistentDataContainer().set(specialBeaconKey, PersistentDataType.BYTE, (byte) 1);
        stack.setItemMeta(meta);
        return stack;
    }

    private void registerDefenseRecipe() {
        NamespacedKey recipeKey = new NamespacedKey(this, "central_defesa_magica");
        Bukkit.removeRecipe(recipeKey);
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, specialBeaconItem());
        recipe.shape("E E", " B ", "G G");
        recipe.setIngredient('E', Material.EMERALD);
        recipe.setIngredient('B', Material.BEACON);
        recipe.setIngredient('G', Material.GOLD_BLOCK);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack reinforcedBeaconItem() {
        ItemStack stack = item(Material.BEACON, "Barreira Mágica Reforçada", "Proteção reforçada contra explosões", "Raio horizontal de 80 blocos e vertical de 100", "Até 16 cargas", "Recarga completa em 45 minutos", "Clique direito para abrir o painel");
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_PURPLE + "Barreira Mágica Roxa");
        meta.getPersistentDataContainer().set(reinforcedBeaconKey, PersistentDataType.BYTE, (byte) 1);
        stack.setItemMeta(meta);
        return stack;
    }

    private void registerReinforcedDefenseRecipe() {
        NamespacedKey recipeKey = new NamespacedKey(this, "barreira_magica_reforcada");
        Bukkit.removeRecipe(recipeKey);
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, reinforcedBeaconItem());
        recipe.shape("ONO", "NBN", "ONO");
        recipe.setIngredient('O', Material.CRYING_OBSIDIAN);
        recipe.setIngredient('N', Material.NETHERITE_INGOT);
        recipe.setIngredient('B', Material.BEACON);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack cannonItem() {
        ItemStack stack = item(Material.BARREL, "Canhão Medieval", "Coloque no chão para montar o canhão", "Use /canhao para mirar e disparar");
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(cannonItemKey, PersistentDataType.BYTE, (byte) 1);
        stack.setItemMeta(meta);
        return stack;
    }

    private void registerCannonRecipe() {
        NamespacedKey recipeKey = new NamespacedKey(this, "canhao_medieval");
        Bukkit.removeRecipe(recipeKey);
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, cannonItem());
        // Receita solicitada: 2 blocos de ferro, 1 redstone, 2 pólvoras,
        // 2 diamantes, 1 pederneira e aço e 1 barril.
        recipe.shape("IDI", "PBF", "DRP");
        recipe.setIngredient('I', Material.IRON_BLOCK);
        recipe.setIngredient('D', Material.DIAMOND);
        recipe.setIngredient('P', Material.GUNPOWDER);
        recipe.setIngredient('B', Material.BARREL);
        recipe.setIngredient('F', Material.FLINT_AND_STEEL);
        recipe.setIngredient('R', Material.REDSTONE);
        Bukkit.addRecipe(recipe);
    }

    private int maxHits(DefenseState d) {
        return d.reinforced ? Math.max(1, Math.min(16, getConfig().getInt("reinforced-defense.max-explosions", 16))) : Math.max(1, Math.min(8, getConfig().getInt("defense.max-explosions", 8)));
    }

    private double defenseHorizontal(DefenseState d) { return getConfig().getDouble(d.reinforced ? "reinforced-defense.horizontal-radius-blocks" : "defense.horizontal-radius-blocks", d.reinforced ? 80.0 : 50.0); }
    private double defenseVertical(DefenseState d) { return getConfig().getDouble(d.reinforced ? "reinforced-defense.vertical-radius-blocks" : "defense.vertical-radius-blocks", d.reinforced ? 100.0 : 50.0); }

    private void openDefenseMenu(Player p, DefenseState d) {
        Inventory inv = Bukkit.createInventory(null, 45, DEFENSE_TITLE);
        ItemStack border = item(Material.PURPLE_STAINED_GLASS_PANE, " ", "Selo arcano");
        for (int i = 0; i < 45; i++) {
            if (i < 9 || i >= 36 || i % 9 == 0 || i % 9 == 8) inv.setItem(i, border);
        }
        int cap = maxHits(d);
        long rechargeEvery = getConfig().getLong(d.reinforced ? "reinforced-defense.full-recharge-minutes" : "defense.full-recharge-minutes", d.reinforced ? 45 : 10) * 60_000L / cap;
        long elapsed = Math.max(0L, System.currentTimeMillis() - d.lastRechargeMillis);
        long remaining = d.hitsRemaining >= cap ? 0L : Math.max(0L, rechargeEvery - elapsed);
        long seconds = (remaining + 999L) / 1000L;
        String nextRecharge = d.hitsRemaining >= cap ? "Carga completa" : "Próxima carga em " + (seconds / 60) + "m " + (seconds % 60) + "s";
        inv.setItem(4, item(Material.AMETHYST_SHARD, "§d✦ NÚCLEO ARCANO ✦", "§7" + (d.reinforced ? "Barreira Mágica Reforçada" : "Central de Defesa Mágica"), "§fLados: " + defenseHorizontal(d) + " blocos", "§fVertical: " + defenseVertical(d) + " blocos", "§fCarga: " + d.hitsRemaining + "/" + maxHits(d), "§f" + nextRecharge));
        inv.setItem(20, item(d.active && d.hitsRemaining > 0 ? Material.CYAN_STAINED_GLASS : Material.GRAY_STAINED_GLASS, "§bEstado do escudo", d.active && d.hitsRemaining > 0 ? "§aBARREIRA ATIVA" : "§cBARREIRA DISSIPADA", "§7O núcleo permanece colocado", "§7A carga retorna gradualmente"));
        inv.setItem(22, item(d.visible ? Material.LIME_DYE : Material.GRAY_DYE, d.visible ? "§aOcultar projeção do escudo" : "§eProjetar escudo mágico", "§7Alterna somente o visual", "§7A proteção continua funcionando", "§7mesmo com a projeção escondida"));
        inv.setItem(24, item(Material.CLOCK, "§eRecarga rúnica", "§7Recuperação completa: " + (d.reinforced ? "45" : "10") + " minutos", "§7A recarga ocorre automaticamente", "§7Não precisa colocar item para recarregar", "§7A recarga ocorre automaticamente"));
        inv.setItem(40, item(Material.BARRIER, "§cFechar painel"));
        openDefenseMenus.put(p.getUniqueId(), d.key);
        p.openInventory(inv);
    }

    private boolean insideDefenseVolume(DefenseState d, Location location) {
        if (d.location.getWorld() == null || location.getWorld() == null || !d.location.getWorld().equals(location.getWorld())) return false;
        double dx = location.getX() - (d.location.getBlockX() + 0.5);
        double dz = location.getZ() - (d.location.getBlockZ() + 0.5);
        double dy = location.getY() - (d.location.getBlockY() + 0.5);
        double horizontal = defenseHorizontal(d);
        double vertical = defenseVertical(d);
        return (dx * dx + dz * dz) / (horizontal * horizontal) + (dy * dy) / (vertical * vertical) <= 1.0;
    }

    private void rechargeDefenses() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (DefenseState d : defenses.values()) {
            int maxHits = maxHits(d);
            long interval = Math.max(1L, getConfig().getLong(d.reinforced ? "reinforced-defense.full-recharge-minutes" : "defense.full-recharge-minutes", d.reinforced ? 45 : 10)) * 60_000L / maxHits;
            if (d.hitsRemaining >= maxHits) { d.lastRechargeMillis = now; continue; }
            long elapsed = Math.max(0L, now - d.lastRechargeMillis);
            int gained = (int)(elapsed / interval);
            if (gained > 0) {
                d.hitsRemaining = Math.min(maxHits, d.hitsRemaining + gained);
                d.lastRechargeMillis += (long)gained * interval;
                if (d.hitsRemaining > 0) d.active = true;
                changed = true;
            }
        }
        if (changed) saveDefenses();
    }

    private void renderDefenseBarriers() {
        rechargeDefenses();
        for (DefenseState d : defenses.values()) {
            if (!d.active || d.hitsRemaining <= 0 || !d.visible || d.location.getWorld() == null) continue;
            double horizontal = defenseHorizontal(d);
            double vertical = defenseVertical(d);
            // Desenha a projeção visual conforme os raios configurados para cada barreira.
            for (int band = -2; band <= 2; band++) {
                double yNorm = band * 0.42;
                double ring = Math.sqrt(Math.max(0, 1.0 - yNorm * yNorm));
                for (int i = 0; i < 24; i++) {
                    double a = (Math.PI * 2.0 * i) / 24.0;
                    double x = Math.cos(a) * horizontal * ring;
                    double z = Math.sin(a) * horizontal * ring;
                    double y = yNorm * vertical;
                    Location particle = d.location.clone().add(0.5 + x, 0.5 + y, 0.5 + z);
                    Particle shieldParticle = d.reinforced ? Particle.DRAGON_BREATH : Particle.SOUL_FIRE_FLAME;
                    d.location.getWorld().spawnParticle(shieldParticle, particle, 1, 0, 0, 0, 0);
                }
            }
        }
    }

    private DefenseState defenseAt(Location location) {
        for (DefenseState d : defenses.values()) {
            if (!d.active || d.hitsRemaining <= 0) continue;
            if (insideDefenseVolume(d, location)) return d;
        }
        return null;
    }

    private void absorbExplosion(Location location) {
        DefenseState d = defenseAt(location);
        if (d == null) return;
        d.hitsRemaining = Math.max(0, d.hitsRemaining - 1);
        if (d.hitsRemaining == 0) {
            d.active = false;
            d.lastRechargeMillis = System.currentTimeMillis();
            d.visible = false;
            d.location.getWorld().playSound(d.location, Sound.BLOCK_BEACON_DEACTIVATE, 1f, 0.7f);
            d.location.getWorld().spawnParticle(Particle.EXPLOSION, d.location.clone().add(0.5, 1, 0.5), 2, 0.4, 0.4, 0.4, 0);
            for (Player player : d.location.getWorld().getPlayers()) {
                if (player.getLocation().distanceSquared(d.location) <= 10000) player.sendMessage(ChatColor.LIGHT_PURPLE + "A barreira da Central de Defesa Mágica se dissipou!");
            }
        } else {
            d.location.getWorld().playSound(d.location, Sound.BLOCK_BEACON_POWER_SELECT, 0.8f, 1.4f);
        }
        saveDefenses();
    }

    private void tell(CommandSender s, String m) {
        s.sendMessage(ChatColor.GOLD + "[Canhoes] " + ChatColor.WHITE + m);
    }

    private Location aimedBarrel(Player p) {
        Block b = p.getTargetBlockExact(getConfig().getInt("cannon.cannon-range-blocks", 65));
        return b != null && b.getType() == Material.BARREL ? b.getLocation() : null;
    }

    private CannonState findCannon(Player p) {
        Location aimed = aimedBarrel(p);
        if (aimed != null && cannons.containsKey(key(aimed))) return cannons.get(key(aimed));
        CannonState best = null;
        double bestDistance = 64;
        for (CannonState c : cannons.values()) {
            if (!c.location.getWorld().equals(p.getWorld())) continue;
            double d = c.location.distanceSquared(p.getLocation());
            if (d < bestDistance) { bestDistance = d; best = c; }
        }
        return best;
    }

    private ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(ChatColor.YELLOW + name);
        List<String> lines = new ArrayList<>();
        for (String line : lore) lines.add(ChatColor.GRAY + line);
        meta.setLore(lines);
        stack.setItemMeta(meta);
        return stack;
    }

    private void openMenu(Player p, CannonState c) {
        Inventory inv = Bukkit.createInventory(null, MENU_SIZE, MENU_TITLE);
        inv.setItem(0, item(Material.AMETHYST_SHARD, "Munição: TNT de Impulso", "TNT de Impulso: " + c.tnt, "Clique para carregar 1 do inventário"));
        inv.setItem(1, item(Material.TNT, "TNT comum não é aceita", "Use a TNT de Impulso do TNTReinforced"));
        inv.setItem(3, item(Material.ARROW, "Girar mira para esquerda", "Yaw: " + Math.round(c.yaw) + "°"));
        inv.setItem(4, item(Material.SPYGLASS, "Ver mira / trajetória", "Elevação: " + Math.round(c.elevation) + "°", "Clique para mostrar trajetória"));
        inv.setItem(5, item(Material.SPECTRAL_ARROW, "Girar mira para direita", "Yaw: " + Math.round(c.yaw) + "°"));
        inv.setItem(7, item(Material.FEATHER, "Baixar elevação", "Elevação: " + Math.round(c.elevation) + "°"));
        inv.setItem(8, item(Material.FIREWORK_ROCKET, "Aumentar elevação", "Elevação: " + Math.round(c.elevation) + "°"));
        inv.setItem(13, item(Material.IRON_BLOCK, "CANHÃO", "TNT de Impulso carregada: " + c.tnt, "Yaw: " + Math.round(c.yaw) + "°", "Elevação: " + Math.round(c.elevation) + "°"));
        inv.setItem(22, item(Material.FLINT_AND_STEEL, "DISPARAR", "Gasta 1 TNT de Impulso", "Alcance máximo: " + getConfig().getInt("cannon.max-range-blocks", 65) + " blocos", "Recarga: " + (getConfig().getLong("cannon.cooldown-ticks", 100) / 20.0) + " segundos"));
        inv.setItem(26, item(Material.BARRIER, "Fechar painel"));
        openMenus.put(p.getUniqueId(), c.key);
        p.openInventory(inv);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { tell(sender, "Use o comando dentro do jogo."); return true; }
        if (args.length > 0 && args[0].equalsIgnoreCase("ajuda")) {
            tell(p, "/canhao criar - registra o barril mirado (admin)");
            tell(p, "/canhao remover - remove o canhão mirado (admin)");
            tell(p, "/canhao defesa - abre a central de defesa mágica que você estiver mirando");
            tell(p, "/canhao receitas - mostra receitas e especificações");
            tell(p, "/canhao - abre a interface do canhão mais próximo");
            return true;
        }
        if (args.length > 0 && (args[0].equalsIgnoreCase("receitas") || args[0].equalsIgnoreCase("crafts"))) {
            tell(p, "RECEITAS (linhas de cima para baixo; espaços são vazios):");
            tell(p, "Canhão: IDI / PBF / DRP — I=bloco de ferro (2), D=diamante (2), P=pólvora (2), B=barril, F=pederneira e aço, R=redstone.");
            tell(p, "Barreira Azul: E E / espaço-B-espaço / G G — E=esmeralda, B=beacon, G=bloco de ouro. 50 horizontal/50 vertical, 8 explosões, recarga 10 min.");
            tell(p, "Barreira Roxa: O N O / N B N / O N O — O=obsidiana chorona, N=lingote de netherita, B=beacon. 80 horizontal/100 vertical, 16 explosões, recarga 45 min.");
            tell(p, "Canhão: alcance máximo 65 blocos, recarga 5 segundos. Usa apenas TNT de Impulso do TNTReinforced 1.3.0.");
            tell(p, "Itens reais e créditos completos: /plugins/MedievalCannons/recipes.yml; integração com TNTReinforced 1.3.0 por zSouul.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("criar")) {
            if (!p.hasPermission("medievalcannons.admin")) { tell(p, "Sem permissão."); return true; }
            Location l = aimedBarrel(p);
            if (l == null) { tell(p, "Mire em um barril a até 65 blocos."); return true; }
            if (cannons.size() >= getConfig().getInt("cannon.max-cannons-per-world", 100)) {
                tell(p, "Limite de canhões registrados atingido."); return true;
            }
            String k = key(l);
            if (cannons.containsKey(k)) { tell(p, "Esse barril já é um canhão."); return true; }
            cannons.put(k, new CannonState(k, l, p.getUniqueId(), p.getLocation().getYaw(), 15));
            saveCannons(); tell(p, "Canhão registrado! Use /canhao para abrir o painel."); return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("remover")) {
            if (!p.hasPermission("medievalcannons.admin")) { tell(p, "Sem permissão."); return true; }
            Location l = aimedBarrel(p);
            if (l == null || cannons.remove(key(l)) == null) { tell(p, "Mire em um canhão registrado."); return true; }
            saveCannons(); tell(p, "Canhão removido."); return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("defesa")) {
            Block target = p.getTargetBlockExact(8);
            if (target == null || target.getType() != Material.BEACON || !defenses.containsKey(key(target.getLocation()))) {
                tell(p, "Mire na Central de Defesa Mágica colocada e use /canhao defesa."); return true;
            }
            openDefenseMenu(p, defenses.get(key(target.getLocation())));
            return true;
        }
        if (!p.hasPermission("medievalcannons.use")) { tell(p, "Sem permissão para usar canhões."); return true; }
        CannonState c = findCannon(p);
        if (c == null) { tell(p, "Não encontrei canhão próximo. Mire em um barril e use /canhao criar."); return true; }
        openMenu(p, c);
        return true;
    }

    @EventHandler public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (DEFENSE_TITLE.equals(e.getView().getTitle())) {
            e.setCancelled(true);
            if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
            String dk = openDefenseMenus.get(p.getUniqueId());
            DefenseState d = dk == null ? null : defenses.get(dk);
            if (d == null) { p.closeInventory(); return; }
            if (e.getRawSlot() == 22) {
                d.visible = !d.visible;
                saveDefenses();
                openDefenseMenu(p, d);
            } else if (e.getRawSlot() == 40) p.closeInventory();
            return;
        }
        if (!MENU_TITLE.equals(e.getView().getTitle())) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        String k = openMenus.get(p.getUniqueId());
        CannonState c = k == null ? null : cannons.get(k);
        if (c == null) { p.closeInventory(); return; }
        switch (e.getRawSlot()) {
            case 0 -> {
                if (!isTntReinforcedAvailable()) tell(p, "TNTReinforced 1.3.0 precisa estar instalado e ativo.");
                else if (!takeImpulseTnt(p)) tell(p, "Você precisa da TNT de Impulso do TNTReinforced.");
                else { c.tnt++; tell(p, "TNT de Impulso carregada: " + c.tnt); }
                openMenu(p,c);
            }
            case 1 -> { tell(p, "O canhão aceita somente TNT de Impulso, não TNT comum nem pólvora."); openMenu(p,c); }
            case 3 -> { c.yaw = normalizeYaw(c.yaw - getConfig().getDouble("cannon.yaw-step-degrees",10)); openMenu(p,c); }
            case 5 -> { c.yaw = normalizeYaw(c.yaw + getConfig().getDouble("cannon.yaw-step-degrees",10)); openMenu(p,c); }
            case 7 -> { c.elevation = Math.max(getConfig().getDouble("cannon.min-elevation-degrees",-5), c.elevation-getConfig().getDouble("cannon.elevation-step-degrees",5)); openMenu(p,c); }
            case 8 -> { c.elevation = Math.min(getConfig().getDouble("cannon.max-elevation-degrees",80), c.elevation+getConfig().getDouble("cannon.elevation-step-degrees",5)); openMenu(p,c); }
            case 4 -> { showTrajectory(p,c); openMenu(p,c); }
            case 22 -> fire(p,c);
            case 26 -> p.closeInventory();
            default -> { }
        }
    }

    @EventHandler public void onDrag(InventoryDragEvent e) {
        if (MENU_TITLE.equals(e.getView().getTitle()) || DEFENSE_TITLE.equals(e.getView().getTitle())) e.setCancelled(true);
    }

    @EventHandler public void onClose(InventoryCloseEvent e) {
        if (MENU_TITLE.equals(e.getView().getTitle())) openMenus.remove(e.getPlayer().getUniqueId());
        if (DEFENSE_TITLE.equals(e.getView().getTitle())) openDefenseMenus.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler public void onSpecialBeaconPlace(BlockPlaceEvent e) {
        ItemMeta meta = e.getItemInHand().getItemMeta();
        if (meta == null) return;
        boolean reinforced = meta.getPersistentDataContainer().has(reinforcedBeaconKey, PersistentDataType.BYTE);
        boolean normal = meta.getPersistentDataContainer().has(specialBeaconKey, PersistentDataType.BYTE);
        if (meta.getPersistentDataContainer().has(cannonItemKey, PersistentDataType.BYTE)) {
            Location loc = e.getBlockPlaced().getLocation();
            String ck = key(loc);
            if (cannons.size() >= getConfig().getInt("cannon.max-cannons-per-world", 100)) { e.setCancelled(true); e.getPlayer().sendMessage(ChatColor.RED + "Limite de canhões atingido."); return; }
            cannons.put(ck, new CannonState(ck, loc, e.getPlayer().getUniqueId(), e.getPlayer().getLocation().getYaw(), getConfig().getDouble("cannon.default-elevation-degrees", 15)));
            saveCannons();
            e.getPlayer().sendMessage(ChatColor.GOLD + "Canhão montado! Use /canhao para abrir o painel.");
            return;
        }
        if (!normal && !reinforced) return;
        Location loc = e.getBlockPlaced().getLocation();
        String k = key(loc);
        int hits = reinforced ? Math.max(1, Math.min(16, getConfig().getInt("reinforced-defense.max-explosions", 16))) : Math.max(1, Math.min(8, getConfig().getInt("defense.max-explosions", 8)));
        defenses.put(k, new DefenseState(k, loc, hits, true, false, System.currentTimeMillis(), reinforced));
        saveDefenses();
        e.getPlayer().sendMessage(ChatColor.LIGHT_PURPLE + (reinforced ? "Barreira Mágica Reforçada ativada!" : "Central de Defesa Mágica ativada!") + " Cargas: " + hits + ".");
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.2f);
    }

    @EventHandler public void onDefenseBeaconInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        Location loc = e.getClickedBlock().getLocation();
        DefenseState d = defenses.get(key(loc));
        if (d == null) return;
        e.setCancelled(true);
        openDefenseMenu(e.getPlayer(), d);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityExplosion(EntityExplodeEvent e) {
        if (defenseAt(e.getLocation()) != null) {
            e.setCancelled(true);
            absorbExplosion(e.getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockExplosion(BlockExplodeEvent e) {
        if (defenseAt(e.getBlock().getLocation()) != null) {
            e.setCancelled(true);
            absorbExplosion(e.getBlock().getLocation());
        }
    }

    @EventHandler public void onDefenseBeaconBreak(org.bukkit.event.block.BlockBreakEvent e) {
        String k = key(e.getBlock().getLocation());
        if (defenses.remove(k) != null) {
            saveDefenses();
            e.getPlayer().sendMessage(ChatColor.LIGHT_PURPLE + "Central de Defesa Mágica removida.");
        }
    }

    private double normalizeYaw(double yaw) {
        while (yaw < 0) yaw += 360;
        while (yaw >= 360) yaw -= 360;
        return yaw;
    }

    private boolean take(Player p, Material m, int amount) {
        if (!p.getInventory().containsAtLeast(new ItemStack(m), amount)) return false;
        Map<Integer, ItemStack> rest = p.getInventory().removeItem(new ItemStack(m, amount));
        return rest.isEmpty();
    }

    private boolean isTntReinforcedAvailable() {
        org.bukkit.plugin.Plugin plugin = Bukkit.getPluginManager().getPlugin("TNTReinforced");
        return plugin != null && plugin.isEnabled();
    }

    private boolean isImpulseTnt(ItemStack stack) {
        if (stack == null || stack.getType() != Material.TNT || !stack.hasItemMeta()) return false;
        ItemMeta meta = stack.getItemMeta();
        return meta.getPersistentDataContainer().has(impulseItemKey, PersistentDataType.BYTE);
    }

    private boolean takeImpulseTnt(Player p) {
        for (int i = 0; i < p.getInventory().getSize(); i++) {
            ItemStack stack = p.getInventory().getItem(i);
            if (isImpulseTnt(stack)) {
                if (stack.getAmount() <= 1) p.getInventory().setItem(i, null);
                else stack.setAmount(stack.getAmount() - 1);
                return true;
            }
        }
        return false;
    }

    private Vector direction(CannonState c) {
        double yawRad = Math.toRadians(c.yaw);
        double pitchRad = Math.toRadians(-c.elevation);
        // Minecraft yaw 0 faces south; positive yaw rotates toward west.
        double x = -Math.sin(yawRad) * Math.cos(pitchRad);
        double y = Math.sin(pitchRad);
        double z = Math.cos(yawRad) * Math.cos(pitchRad);
        return new Vector(x,y,z).normalize();
    }

    private Location muzzle(CannonState c) {
        return c.location.clone().add(0.5, 0.6, 0.5).add(direction(c).multiply(1.0));
    }

    private void showTrajectory(Player p, CannonState c) {
        Location start = muzzle(c);
        Vector v = direction(c).multiply(getConfig().getDouble("cannon.projectile-speed",1.8));
        double gravity = getConfig().getDouble("cannon.gravity-per-tick",0.045);
        for (int t=0; t<Math.min(getConfig().getInt("cannon.projectile-life-ticks",100), (int)(getConfig().getDouble("cannon.max-range-blocks",65.0) / Math.max(0.1, getConfig().getDouble("cannon.projectile-speed",1.8)))); t++) {
            double x = start.getX() + v.getX()*t;
            double y = start.getY() + v.getY()*t - 0.5*gravity*t*t;
            double z = start.getZ() + v.getZ()*t;
            if (y < p.getWorld().getMinHeight()) break;
            Location dot = new Location(p.getWorld(),x,y,z);
            p.spawnParticle(Particle.CRIT, dot, 1, 0,0,0,0);
            if (dot.getBlock().getType().isSolid()) break;
        }
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.6f, 1.5f);
    }

    private void fire(Player p, CannonState c) {
        if (!isTntReinforcedAvailable()) {
            tell(p, "TNTReinforced 1.3.0 precisa estar instalado e ativo; nenhum disparo foi consumido.");
            return;
        }
        long now = System.currentTimeMillis();
        long until = cooldowns.getOrDefault(c.key, 0L);
        if (now < until) { tell(p, "O canhão ainda está recarregando."); return; }
        if (c.tnt < 1) { tell(p, "Carregue TNT de Impulso no painel primeiro."); return; }

        c.tnt--;
        cooldowns.put(c.key, now + getConfig().getLong("cannon.cooldown-ticks", 100) * 50L);
        Location start = muzzle(c);
        Snowball projectile = c.location.getWorld().spawn(start, Snowball.class, ball -> {
            ball.setShooter(p);
            ball.setVelocity(direction(c).multiply(getConfig().getDouble("cannon.projectile-speed", 1.8)));
            ball.getPersistentDataContainer().set(projectileKey, PersistentDataType.BYTE, (byte) 1);
            ball.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, p.getUniqueId().toString());
            ball.setCustomName("Bala de canhão");
            ball.setCustomNameVisible(false);
        });

        new BukkitRunnable() {
            int ticks = 0;
            double travelled = 0.0;
            Location previous = projectile.getLocation().clone();

            @Override public void run() {
                if (!projectile.isValid() || projectile.isDead()) { cancel(); return; }
                ticks++;
                Location current = projectile.getLocation();
                if (current.getWorld().equals(previous.getWorld())) travelled += current.distance(previous);
                previous = current.clone();

                if (getConfig().getBoolean("cannon.show-trajectory", true)) {
                    projectile.getWorld().spawnParticle(Particle.CRIT, current, 2, 0.04, 0.04, 0.04, 0.01);
                }

                boolean rangeReached = travelled >= getConfig().getDouble("cannon.max-range-blocks", 65.0);
                boolean lifetimeReached = ticks >= getConfig().getInt("cannon.projectile-life-ticks", 100);
                if (rangeReached || lifetimeReached) {
                    projectile.remove();
                    spawnImpulseTnt(current, p);
                    cancel();
                }
            }
        }.runTaskTimer(this, 1L, 1L);

        p.closeInventory();
        p.sendMessage(ChatColor.GOLD + "[Canhões] FOGO! TNT de Impulso restante: " + c.tnt);
        c.location.getWorld().playSound(start, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.7f);
    }

    /**
     * Cria uma TNTPrimed marcada com o PersistentDataContainer que o TNTReinforced
     * 1.3.0 verifica (namespace tntreinforced, chave tnt_impulse_entity). Assim,
     * o evento de explosão passa pelo sistema real de TNT de Impulso, em vez de
     * criar uma explosão genérica que ignora a integração.
     */
    private void spawnImpulseTnt(Location location, Entity source) {
        if (!isTntReinforcedAvailable() || location.getWorld() == null) {
            if (source instanceof Player player) tell(player, "TNTReinforced não está ativo; o projétil foi encerrado sem explosão.");
            return;
        }
        TNTPrimed tnt = location.getWorld().spawn(location, TNTPrimed.class, entity -> {
            entity.setFuseTicks(1);
            if (source != null) entity.setSource(source);
            entity.getPersistentDataContainer().set(impulseEntityKey, PersistentDataType.BYTE, (byte) 1);
        });
        tnt.setVelocity(new Vector(0, 0, 0));
    }

    @EventHandler public void onProjectileHit(org.bukkit.event.entity.ProjectileHitEvent e) {
        if (!(e.getEntity() instanceof Snowball ball)) return;
        if (!ball.getPersistentDataContainer().has(projectileKey, PersistentDataType.BYTE)) return;
        Location hit = ball.getLocation().clone();
        Entity shooter = ball.getShooter() instanceof Entity entity ? entity : null;
        ball.remove();
        spawnImpulseTnt(hit, shooter);
    }
}
