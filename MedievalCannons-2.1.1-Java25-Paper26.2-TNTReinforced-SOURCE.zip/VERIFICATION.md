# Relatório de verificação — MedievalCannons 2.1.1

## Resultado
- Sintaxe YAML verificada: `plugin.yml`, `config.yml`, `recipes.yml` e workflow.
- Receita do canhão conferida com as quantidades solicitadas.
- Chaves PDC da TNT de Impulso comparadas com o JAR TNTReinforced 1.3.0 fornecido:
  - Item: `tntreinforced:tnt_impulse_item`
  - Entidade: `tntreinforced:tnt_impulse_entity`
- Workflow exige classe principal, descritores, receitas e JAR maior que 10 KB.
- O plugin não deve disparar se TNTReinforced estiver ausente/desativado.
- A TNT de impacto é marcada com a chave de entidade que o TNTReinforced reconhece.

## Limites
Não houve compilação real nesta sessão: o ambiente possui Java 21 e não tem Gradle nem JDK 25. Não foi possível iniciar um servidor Paper/Purpur 26.2. Portanto, este relatório é de inspeção estática e não certifica 100% de ausência de bugs. Execute GitHub Actions e teste em servidor de teste antes de usar em produção.

## Receita do canhão
Grade:
`IDI`
`PBF`
`DRP`

- I: 2 blocos de ferro
- D: 2 diamantes
- P: 2 pólvoras
- B: 1 barril
- F: 1 pederneira e aço (isqueiro)
- R: 1 redstone

As receitas azul e roxa permanecem como definidas no projeto. As receitas completas, itens vanilla e créditos estão em `src/main/resources/recipes.yml`; o plugin copia esse arquivo para sua pasta de dados ao iniciar.
